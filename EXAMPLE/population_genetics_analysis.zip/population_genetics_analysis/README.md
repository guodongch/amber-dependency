# ======================= Population Genetics Analysis ==============================
VCF File: ./ALL.chrMT.phase3_callmom-v0_4.20130502.genotypes.vcf.gz
Metadata File: ./samples_metadata.tsv

VCF File: ./ALL.chrY.phase3_integrated_v2b.20130502.genotypes.vcf.gz
Metadata File: ./samples_metadata.tsv

# You can download the data at: https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/release/20130502/
VCF File: ./ALL.chr22.phase3_shapeit2_mvncall_integrated_v5b.20130502.genotypes.vcf.gz
Metadata File: ./samples_metadata.tsv
