
# ========================== DIAMOND ============================
# makedb
Protein fasta file: ./VviM.pep.fa

# Blastp
Protein fasta file: ./VviM.pep.fa
dnmd file: 

# ================== Molicular Evolution Analysis ================
# Synteny
GFF File: ./VviM.gff
Lens File: ./VviM_in.tsv
Ancestor File: ./vvi.chr.col.txt

Blast File: ./blast.tsv  # DIAMOND Blast result


# Ka vs ks 
# ka ks
nucleartide fasta: ./Vvi.cds.fa
protein fasta: ./VviM.pep.fa